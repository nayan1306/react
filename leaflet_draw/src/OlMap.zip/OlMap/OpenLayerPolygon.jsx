import { useEffect, useRef, useState } from "react";
import "./ol.css";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import TileWMS from "ol/source/TileWMS";
import OSM from "ol/source/OSM";
import MousePosition from "ol/control/MousePosition";
import { defaults as defaultControls } from "ol/control";
import { createStringXY } from "ol/coordinate";
import Draw from "ol/interaction/Draw";
import Modify from "ol/interaction/Modify";
import Select from "ol/interaction/Select";
import { Vector as VectorLayer } from "ol/layer";
import { Vector as VectorSource } from "ol/source";
import { Fill, Stroke, Style } from "ol/style";
import { click } from "ol/events/condition";
import styles from './openlayerpolygon.module.css';

const getRandomColor = () => {
  const letters = '0123456789ABCDEF';
  let color = '#';
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
};

function OpenLayerMap() {
  const mapRef = useRef(null);
  const vectorSourceRef = useRef(new VectorSource());
  const mapInstance = useRef(null);
  const drawInteraction = useRef(null);
  const modifyInteraction = useRef(null);
  const selectInteraction = useRef(null);
  const deleteModeRef = useRef(false);
  const [polygonFeatures, setPolygonFeatures] = useState([]);

  useEffect(() => {
    if (!mapRef.current) {
      console.error("Map container not found");
      return;
    }

    if (mapInstance.current) return;

    const initialView = new View({
      projection: "EPSG:4326",
      center: [78.9629, 20.5937],
      zoom: 5,
    });

    const map = new Map({
      controls: defaultControls().extend([
        new MousePosition({
          coordinateFormat: createStringXY(4),
          projection: "EPSG:4326",
          target: document.getElementById("mouse-position"),
        }),
      ]),
      target: mapRef.current,
      view: initialView,
    });

    const osmLayer = new TileLayer({
      source: new OSM(),
      zIndex: 0,
    });

    const wmsLayer = new TileLayer({
      source: new TileWMS({
        projection: "EPSG:4326",
        url: "https://vedas.sac.gov.in/ridam_server3/wms",
        params: {
          name: "RDSGrdient",
          layers: "T0S0M0",
          PROJECTION: "EPSG:4326",
          ARGS: "merge_method:max;dataset_id:T3S1P1;from_time:20240705;to_time:20240725;indexes:1",
          styles: "[0:FFFFFF00:1:f0ebecFF:25:d8c4b6FF:50:ab8a75FF:75:917732FF:100:70ab06FF:125:459200FF:150:267b01FF:175:0a6701FF:200:004800FF:251:001901FF;nodata:FFFFFF00]",
          LEGEND_OPTIONS: "columnHeight:400;height:100",
        },
      }),
      opacity: 1,
      zIndex: 1,
    });

    const vectorLayer = new VectorLayer({
      source: vectorSourceRef.current,
      style: (feature) => {
        const color = feature.get('color') || '#FF0000';
        return new Style({
          fill: new Fill({
            color: 'rgba(255, 255, 255, 0)', // Transparent fill
          }),
          stroke: new Stroke({
            color: color,
            width: 4,
          }),
        });
      },
      zIndex: 2,
    });

    map.addLayer(osmLayer);
    map.addLayer(wmsLayer);
    map.addLayer(vectorLayer);

    drawInteraction.current = new Draw({
      source: vectorSourceRef.current,
      type: 'Polygon',
    });

    modifyInteraction.current = new Modify({
      source: vectorSourceRef.current,
    });

    selectInteraction.current = new Select({
      condition: click,
      layers: [vectorLayer],
    });

    map.addInteraction(drawInteraction.current);
    map.addInteraction(modifyInteraction.current);
    map.addInteraction(selectInteraction.current);

    const handleDeleteFeature = (e) => {
      if (deleteModeRef.current) {
        const features = map.getFeaturesAtPixel(e.pixel);
        if (features.length > 0) {
          const feature = features[0];
          vectorSourceRef.current.removeFeature(feature);
          updatePolygonFeatures();
        }
      }
    };

    map.on('click', handleDeleteFeature);

    drawInteraction.current.on('drawstart', () => {
      console.log('Polygon drawing started');
      // drawMask(); // Call drawMask here to apply mask immediately
    });
    

    drawInteraction.current.on('drawend', (event) => {
      console.log('Polygon drawing finished');
      const feature = event.feature;
      feature.set('color', getRandomColor());
      updatePolygonFeatures();
      // drawMask(); // Ensure mask is drawn after the feature is added
    });

    const updatePolygonFeatures = () => {
      const features = [];
      vectorSourceRef.current.forEachFeature((feature) => {
        features.push(feature);
      });
      setPolygonFeatures(features);
    };

    mapInstance.current = map;

    return () => {
      if (mapInstance.current) {
        mapInstance.current.removeInteraction(drawInteraction.current);
        mapInstance.current.removeInteraction(modifyInteraction.current);
        mapInstance.current.removeInteraction(selectInteraction.current);
        mapInstance.current.un('click', handleDeleteFeature);
        mapInstance.current.setTarget(null);
        mapInstance.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!mapRef.current || polygonFeatures.length === 0) return;

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');

    if (!context) return;

    canvas.style.position = 'absolute';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.pointerEvents = 'none';

    mapRef.current.appendChild(canvas);

    const resizeCanvas = () => {
      canvas.width = mapRef.current.clientWidth;
      canvas.height = mapRef.current.clientHeight;
      drawMask();
    };

    const drawMask = () => {
      console.log('Drawing mask...');
      
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.fillStyle = 'rgba(0, 0, 0, 0.5)';
      context.fillRect(0, 0, canvas.width, canvas.height);
      
      context.globalCompositeOperation = 'destination-out';
      
      polygonFeatures.forEach((feature, index) => {
        console.log(`Processing feature ${index + 1}`);
        
        const coordinates = feature.getGeometry().getCoordinates()[0];
        console.log(`Coordinates: ${JSON.stringify(coordinates)}`);
        
        context.beginPath();
        coordinates.forEach(([x, y], i) => {
          const [px, py] = mapInstance.current.getPixelFromCoordinate([x, y]);
          console.log(`Coordinate (${x}, ${y}) converted to pixel (${px}, ${py})`);
          
          i === 0 ? context.moveTo(px, py) : context.lineTo(px, py);
        });
        context.closePath();
        context.fill();
        
        console.log('Feature drawn');
      });

      context.globalCompositeOperation = 'source-over';
      console.log('Mask drawing completed');
    };

    const handleMoveEnd = () => {
      drawMask();
    };

    mapInstance.current.on('moveend', handleMoveEnd);

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    return () => {
      if (canvas.parentNode) {
        canvas.parentNode.removeChild(canvas);
      }
      window.removeEventListener('resize', resizeCanvas);
      mapInstance.current.un('moveend', handleMoveEnd);
    };
  }, [polygonFeatures]);

  const enableDrawing = () => {
    if (mapInstance.current) {
      mapInstance.current.removeInteraction(modifyInteraction.current);
      mapInstance.current.removeInteraction(selectInteraction.current);
      mapInstance.current.addInteraction(drawInteraction.current);
      deleteModeRef.current = false;
    }
  };

  const enableModifying = () => {
    if (mapInstance.current) {
      mapInstance.current.removeInteraction(drawInteraction.current);
      mapInstance.current.removeInteraction(selectInteraction.current);
      mapInstance.current.addInteraction(modifyInteraction.current);
      deleteModeRef.current = false;
    }
  };

  const enableDeleting = () => {
    if (mapInstance.current) {
      mapInstance.current.removeInteraction(drawInteraction.current);
      mapInstance.current.removeInteraction(modifyInteraction.current);
      mapInstance.current.addInteraction(selectInteraction.current);
      deleteModeRef.current = true;
    }
  };

  return (
    <>
      <h2>Open Layer Map</h2>
      <div id="map" ref={mapRef} style={{ position: 'relative', width: "100%", height: "800px" }}>
        <div id="toolbar" className={styles.toolbar}>
          <button className={styles.button} onClick={enableDrawing}>Draw Polygon</button>
          <button className={styles.button} onClick={enableModifying}>Edit Polygon</button>
          <button className={styles.button} onClick={enableDeleting}>Delete Polygon</button>
        </div>
      </div>
      <div id="mouse-position"></div>
    </>
  );
}

export default OpenLayerMap;
